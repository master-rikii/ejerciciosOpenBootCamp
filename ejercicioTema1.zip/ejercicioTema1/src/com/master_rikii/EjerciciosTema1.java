package com.master_rikii;
public class EjerciciosTema1 {
    public static void main(String[] args) {
        int number1 = 123;
        short number2 = 1;
        long number3 = 50L;
        char letra = 'a';
        double decimal1 = 4.9d;
        float decimal2 = 4.99f;
        boolean verdadero = true;
        boolean falso = false;
        String nombre = "RIKII";

        System.out.println(number1);
        System.out.println(number2);
        System.out.println(number3);
        System.out.println(letra);
        System.out.println(decimal1);
        System.out.println(decimal2);
        System.out.println(verdadero);
        System.out.println(falso);
        System.out.println(nombre);

    }
}
